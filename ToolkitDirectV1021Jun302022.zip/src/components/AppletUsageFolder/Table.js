/* eslint-disable react/jsx-key */
import React, { Component } from "react";
import { withStyles, makeStyles } from "@material-ui/core/styles";
import Table from "@material-ui/core/Table";
import TableBody from "@material-ui/core/TableBody";
import TableCell from "@material-ui/core/TableCell";
import TableContainer from "@material-ui/core/TableContainer";
import TableHead from "@material-ui/core/TableHead";
import TableRow from "@material-ui/core/TableRow";
import "./Table.css";
import { PopupUserinputDialog } from "./PopupUserInput";
// import {DIALOG } from  './utilsDB/helper2DB';

const styles = (theme) => ({
  customTableContainer: {
    overflowX: "initial",
  },
  rootTableHead: {
    backgroundColor: "#4775ae",
    fontFamily: "Trebuchet MS,Arial,Helvetica,sans-serif",
    fontSize: "14px",
    lineHeight: ".6rem",
  },
  rootTableCell: {
    border: "3px solid #fff",
    fontFamily: "Trebuchet MS,Arial,Helvetica,sans-serif",
    fontSize: "16px",
    padding: ".15em .15em .15em .45em",
  },
  MuiPaper: {
    elevation0: {
      boxShadow: "unset",
      borderTop: "1px solid rgb(150, 150, 150)",
      borderRight: "1px solid rgb(136, 136, 136)",
      borderBottom: "1px solid rgb(150, 150, 150)",
      borderLeft: "1px solid rgb(136, 136, 136)",
    },
    rounded: { borderRadius: "2px" },
  },
  headTableCell: {
    color: "#fff",
    fontWeight: 600,
    lineHeight: 1.05,
    "&:hover": {
      backgroundColor: "#d2d2d2",
      webkitTransition: "background-color 200ms ease-out",
      mstransition: "background-color 200ms ease-out",
      transition: "background-color 200ms ease-out",
      cursor: "pointer",
    },
  },
  rootTableRow: {
    backgroundColor: (props) => {
      if (props.data.colorLevel === "NA") {
        return "white";
      } else {
        return props.data.colorLevel;
      }
    },
    "&:nth-of-type(odd)": {
      backgroundColor: "#e2e2e2",
    },
    "&:nth-of-type(even)": {
      backgroundColor: "#f3f7f4",
    },
    "&:nth-of-type(odd):hover": {
      backgroundColor: "#d2d2d2",
      webkitTransition: "background-color 200ms ease-out",
      mstransition: "background-color 200ms ease-out",
      transition: "background-color 200ms ease-out",
    },
    "&:nth-of-type(even):hover": {
      backgroundColor: "#d3dcd5",
      webkitTransition: "background-color 200ms ease-out",
      mstransition: "background-color 200ms ease-out",
      transition: "background-color 200ms ease-out",
    },
    "& > th:not(:last-child)": {
      borderRight: "3px solid #fff",
    },
    "& > th:not(:first-child)": {
      borderLeft: "3px solid #fff",
    },
    "& > td:not(:last-child)": {
      borderRight: "3px solid #fff",
    },
    "& > td:not(:first-child)": {
      borderLeft: "3px solid #fff",
    },
    "&$tableRowSelected, &$tableRowSelected:hover": {
      backgroundColor: "lightYellow",
    },
  },
  tableRowSelected: {
    backgroundColor: "lightYellow",
  },
});

/* const useStylesMuiTableHead = makeStyles({
   root: {
     backgroundColor: "#7399c6",
   },
 });
 
 const useStylesMuiTableCell = makeStyles({
   root: {
     border: "3px solid #fff",
     fontFamily: "Trebuchet MS,Arial,Helvetica,sans-serif",
     padding: ".5em .5em",
   },
   head: {
     color: "#fff",
     fontWeight: 700,
   },
 });
 
 const useStylesMuiTableRow = makeStyles({
   root: {
     "&:nth-of-type(odd)": {
       backgroundColor: "#ececec",
     },
     "&:nth-of-type(even)": {
       backgroundColor: "#f3f7f4",
     },
     "&:nth-of-type(odd):hover": {
       backgroundColor: "#d2d2d2",
       webkitTransition: "background-color 200ms ease-out",
       mstransition: "background-color 200ms ease-out",
       transition: "background-color 200ms ease-out",
     },
     "&:nth-of-type(even):hover": {
       backgroundColor: "#d3dcd5",
       webkitTransition: "background-color 200ms ease-out",
       mstransition: "background-color 200ms ease-out",
       transition: "background-color 200ms ease-out",
     },
     "& > th:not(:last-child)": {
       borderRight: "3px solid #fff",
     },
     "& > th:not(:first-child)": {
       borderLeft: "3px solid #fff",
     },
     "& > td:not(:last-child)": {
       borderRight: "3px solid #fff",
     },
     "& > td:not(:first-child)": {
       borderLeft: "3px solid #fff",
     },
   },
 });
  */

/* const classesHead = useStylesMuiTableHead();
 const classesCell = useStylesMuiTableCell();
 const classes = useStylesMuiTableRow(); */

//export default function CustomizedTables({ data, options }) {

class EnhancedTable extends Component {
  constructor(props) {
    super(props);
    this.state = {
      data: this.props.data,
      sorts: { ordered: 0, direction: 0 },
      sourceRow: -1,
      showConfirm: false,
    };
    this.message = "";
    this.selectedRow = this.props.selectedRows;
  }

  componentWillReceiveProps(props) {
    if (
      props.selectedRows !== this.props.selectedRows ||
      props.data !== this.props.data
    ) {
      this.selectedRow = props.selectedRows;
      this.setState({ data: props.data });
    }
  }

  clickImageHover = (k) => {
    //console.log(k)
    this.setState({ sourceRow: k });
  };

  clickHeader = (k) => {
    //const reverse=!this.state.reverse;
    let data = this.state.data;
    let newSort = this.state.sorts;

    let sort = this.props.sort(k, data, newSort, this.props.options);
    data = sort.data;
    newSort = sort.newSort;

    /* if(k=== Object.keys(this.props.options.header)[0])
     {
       data.sort((a, b) => {
         let fa = a.designedFor.toLowerCase(),
             fb = b.designedFor.toLowerCase();
     
         if (fa < fb) {
             return -1;
         }
         if (fa > fb) {
             return 1;
         }
         return 0;
         });
         
         newSort.ordered=0;
         newSort.direction=newSort.direction===0?1:0;
         if(newSort.direction===1)
           data.reverse();
     }
     else if(k=== Object.keys(this.props.options.header)[1])
     {
       data.sort((a, b) => {
         let fa = a.clientName.toLowerCase(),
             fb = b.clientName.toLowerCase();
     
         if (fa < fb) {
             return -1;
         }
         if (fa > fb) {
             return 1;
         }
         return 0;
         });
         
         newSort.ordered=0;
         newSort.direction=newSort.direction===0?1:0;
         if(newSort.direction===1)
           data.reverse();
     }else if(k=== Object.keys(this.props.options.header)[2])
     {
       data.sort((a, b) => {
         let fa = a.designedBy.toLowerCase(),
             fb = b.designedBy.toLowerCase();
     
         if (fa < fb) {
             return -1;
         }
         if (fa > fb) {
             return 1;
         }
         return 0;
         });
         
         newSort.ordered=0;
         newSort.direction=newSort.direction===0?1:0;
         if(newSort.direction===1)
           data.reverse();
     }
     else if(k=== Object.keys(this.props.options.header)[3])
     {
       
         data.sort((a, b) => {
           let da = new Date(a.dateModified),
               db = new Date(b.dateModified);
           return da - db;})
         newSort.ordered=2;
         newSort.direction=newSort.direction===0?1:0;
         if(newSort.direction===1)
                   data.reverse();
     }    
     else if(k=== Object.keys(this.props.options.header)[4])
     {
       data.sort((a, b) => {
         let fa = a.applet.toLowerCase(),
             fb = b.applet.toLowerCase();
     
         if (fa < fb) {
             return -1;
         }
         if (fa > fb) {
             return 1;
         }
         return 0;
         });
         
         newSort.ordered=3;
         newSort.direction=newSort.direction===0?1:0;
         if(newSort.direction===1)
           data.reverse();
     }
     
     else if(k=== Object.keys(this.props.options.header)[5])
     {
         data.sort((a, b) => b.insuranceAmount - a.insuranceAmount)
         newSort.ordered=4;
         newSort.direction=newSort.direction===0?1:0;
         if(newSort.direction===1)
                   data.reverse();
     }     */
    this.setState({ data: data, sorts: newSort });
  };

  propsUnloadMessage = (mode) => {
    this.setState({ showConfirm: false });
    if (mode) {
      this.props.deleteCase(this.state.sourceRow);
    }
    //this.props.deleteCase(k.id)
    this.selectedRow = [];
  };

  clickLoadCase = (k) => {
    this.props.openCaseForEdit(this.props.GUID(k), k.applet);
  };

  clickSelectCase = (row) => {
    this.selectedRow = [];
    this.selectedRow.push(this.props.GUID(row));
    this.props.updateSelectedRow(this.props.GUID(row), row.applet);
  };

  render() {
    const { classes } = this.props;
    const lang = this.props.language;

    //console.log(this.state.data);

    /* const source1= require("./imagesDB/deleteCaseActive1.png")
 const source2= require("./imagesDB/deleteCase.png")
 
 
 const edit1= require("./imagesDB/editCaseActive.png")
 const edit2= require("./imagesDB/editCase.png")
 
 const select1= require("./imagesDB/selectCaseActive.png")
 const select2= require("./imagesDB/selectCase.png")
 
 const expand1= require("./imagesDB/expandActive.png")
 const expand2= require("./imagesDB/expand.png")
 
  */ const inputFields = [];
    /*  let deleteTitle=DIALOG[lang].deleteTitle 
    
    const inputButtons=[];
    inputButtons.push({itemName:1,title:DIALOG[lang].deleteCancel})
    inputButtons.push({itemName:2,title:DIALOG[lang].deleteOK})
   */
    //console.log(this.props.selectedRows)

    //this.state.data.map((row, i) => {console.log(i,row); console.log(this.props.GUID(row));console.log(this.props.GUID(row)) })

    const colorLevel = {};

    return (
      <div>
        <TableContainer classes={{ root: classes.customTableContainer }}>
          <Table
            aria-label="customized table"
            stickyHeader
            aria-label="sticky table"
            style={{ tableLayout: "fixed", width: "95%", overflowX: "auto" }}
          >
            <colgroup>
              <col
                style={{
                  width: this.props.width[0],
                  minWidth: this.props.minWidth[0],
                }}
              />
              <col
                style={{
                  width: this.props.width[1],
                  minWidth: this.props.minWidth[1],
                }}
              />
              <col
                style={{
                  width: this.props.width[2],
                  minWidth: this.props.minWidth[2],
                }}
              />
              <col
                style={{
                  width: this.props.width[3],
                  minWidth: this.props.minWidth[3],
                }}
              />
              <col
                style={{
                  width: this.props.width[4],
                  minWidth: this.props.minWidth[4],
                }}
              />
              <col
                style={{
                  width: this.props.width[5],
                  minWidth: this.props.minWidth[5],
                  maxWidth: this.props.minWidth[5],
                }}
              />
              <col
                style={{
                  width: this.props.width[6],
                  minWidth: this.props.minWidth[6],
                  maxWidth: this.props.minWidth[6],
                }}
              />
            </colgroup>
            {this.props.options.header !== undefined && (
              <TableHead>
                <TableRow classes={{ root: classes.rootTableRow }}>
                  {Object.keys(this.props.options.header).map((k) => (
                    <TableCell
                      onClick={this.clickHeader.bind(this, k)}
                      classes={{
                        root: classes.rootTableHead,
                        head: classes.headTableCell,
                      }}
                      align={this.props.options.header[k].align}
                    >
                      {this.props.options.header[k].title}
                    </TableCell>
                  ))}
                </TableRow>
              </TableHead>
            )}
            {/* {this.state.showConfirm &&< ConfirmDialog open={this.state.showConfirm} language={this.props.language} message={this.message} propsUnloadMessage={this.propsUnloadMessage}>...</ConfirmDialog>} */}
            {this.state.showConfirm && (
              <PopupUserinputDialog
                openDialog={this.state.showConfirm}
                language={lang}
                respondToInput={this.propsUnloadMessage}
                inputFields={inputFields}
                // inputButtons={inputButtons}
                title={this.message}
                buttonWidth="130px"
              />
            )}

            <TableBody>
              {this.state.data.map((row, i) => {
                return (
                  <TableRow
                    classes={{
                      root: classes.rootTableRow,
                      selected: classes.tableRowSelected,
                    }}
                    key={i}
                    /*  onClick={() =>{this.selectedRow=[];this.selectedRow.push(row.caseGUID); this.clickSelectCase.bind(this, row)}    } */
                  >
                    {Object.keys(this.props.options.data).map((k) => {
                      return (
                        <TableCell
                          classes={{ root: classes.rootTableCell }}
                          style={
                            k !== this.props.color
                              ? {}
                              : {
                                  backgroundColor:
                                    this.props.data[i].colorDisplay,
                                }
                          }
                          align={this.props.options.data[k].align}
                        >
                          {row[k]}
                        </TableCell>
                      );
                    })}
                  </TableRow>
                );
              })}
            </TableBody>
          </Table>
        </TableContainer>

        {/*  <DataTable
    dataColTitles={["client","designed By","date","applet"] }
    dataProjection={data1}
    gridTitle={"clientapplet"   }
    language={this.props.language}
  /> */}
      </div>
    );
  }
}

export default withStyles(styles, { withTheme: true })(EnhancedTable);
