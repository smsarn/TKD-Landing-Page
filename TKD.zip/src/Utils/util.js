﻿import {buildMode } from '../../package.json';

export const TOOLKIT = {
	en: {
		Title: 'PPI Toolkit Direct',
		Home: 'Home',
		Applets:'Applets',
		INA: 'Insurance Needs Analysis',
		WL: 'Insurance for Your Whole Life',
		EP: 'Protecting Your Estate',
        PA: 'Practice Assistant',
        LIFO: 'Life Insurance Funding Options'
	},
	fr: {
		Title: 'Boîte à outils directe- PPI',
		Home: 'Principal',
		Applets: 'Applets',
		INA: "Analyse des besoins en matière d'assurance",
		WL: 'L\'assurance pour votre vie entière',
        EP: 'Protection de votre patrimoine',
        PA: 'Assistant à la conformité',
        LIFO: "Modes de financement de l'assurance vie"
	}
}


export const PATHS = {
		Home: '/',
        PA: '/PracticeAssistant',
        INA:'/INA',
        EP:'/EstateProtection',
        WL:'/WholeLife',
        LIFO:'/LIFO'
}


/* export const APP_SITE_INA={
		//const APP_SITE_INA_AZURE: "https://ppitoolkitdirectina.azurewebsites.net/INA",
	APP_SITE_INA_PROD: "https://toolkitdirectsnap.ppi.ca",
	APP_SITE_INA_TEST: "https://test-tkdirectsnap.ppi.ca",
	APP_SITE_INA_LOCAL: "http://localhost:8085/"
}

export const APP_SITE_LIFO = {
    APP_SITE_LIFO_PROD: "https://toolkitdirectlifo.ppi.ca",
    APP_SITE_LIFO_TEST: "https://test-tkdirectlifo.ppi.ca",
    APP_SITE_LIFO_LOCAL: "http://localhost:8089/"
}


export const APP_SITE_WHOLELIFE = {
	//APP_SITE_WHOLELIFE_AZURE_="https://ppitoolkitdirectina.azurewebsites.net/INA",
	APP_SITE_WHOLELIFE_PROD: "https://toolkitdirectwholelife.ppi.ca",
	APP_SITE_WHOLELIFE_TEST: "https://test-tkdirectwholelife.ppi.ca",
	APP_SITE_WHOLELIFE_LOCAL: "http://localhost:8086/"
}

export const APP_SITE_PRACTICEASSISTANT = {
    //APP_SITE_WHOLELIFE_AZURE_="https://ppitoolkitdirectina.azurewebsites.net/INA",
    APP_SITE_PRACTICEASSISTANT_PROD: "https://toolkitdirectpracticeassistant.ppi.ca",
    APP_SITE_PRACTICEASSISTANT_TEST: "https://test-tkdirectpracticeassistant.ppi.ca",
    APP_SITE_PRACTICEASSISTANT_LOCAL: "http://localhost:8087/"
}
 */
/* export const APP_SITE_ESTATEPROTECTION = {
    //APP_SITE_PRACTICEASSISTANT_AZURE_="https://ppitoolkitdirectina.azurewebsites.net/INA",
    APP_SITE_ESTATEPROTECTION_PROD: "https://toolkitdirectestateprotection.ppi.ca",
    APP_SITE_ESTATEPROTECTION_TEST: "https://test-tkdirectestateprotection.ppi.ca",
    APP_SITE_ESTATEPROTECTION_LOCAL: "http://localhost:8088/"
} */

const APP_SITE_INA=[
    //const APP_SITE_INA_AZURE: "https://ppitoolkitdirectina.azurewebsites.net/INA",
    "http://localhost:8085/", // APP_SITE_INA_LOCAL: 
    "https://test-tkdirectsnap.ppi.ca", // APP_SITE_INA_TEST: 
    "https://toolkitdirectsnap.ppi.ca", // APP_SITE_INA_PROD: 
]

const APP_SITE_LIFO = [
    "http://localhost:8089/", // APP_SITE_LIFO_LOCAL:
    "https://test-tkdirectlifo.ppi.ca", // APP_SITE_LIFO_TEST: 
    "https://toolkitdirectlifo.ppi.ca", //APP_SITE_LIFO_PROD: ,
]


const APP_SITE_WHOLELIFE = [
    //APP_SITE_WHOLELIFE_AZURE_="https://ppitoolkitdirectina.azurewebsites.net/INA",
    "http://localhost:8086/", //APP_SITE_WHOLELIFE_LOCAL: 
    "https://test-tkdirectwholelife.ppi.ca", //APP_SITE_WHOLELIFE_TEST: 
    "https://toolkitdirectwholelife.ppi.ca", // APP_SITE_WHOLELIFE_PROD: 

]

const APP_SITE_PRACTICEASSISTANT = [
    //APP_SITE_WHOLELIFE_AZURE_="https://ppitoolkitdirectina.azurewebsites.net/INA",
    "http://localhost:8087/", //APP_SITE_PRACTICEASSISTANT_LOCAL:
    "https://test-tkdirectpracticeassistant.ppi.ca", //APP_SITE_PRACTICEASSISTANT_TEST: 
    "https://toolkitdirectpracticeassistant.ppi.ca", //APP_SITE_PRACTICEASSISTANT_PROD: 
]

const APP_SITE_ESTATEPROTECTION = [
    //APP_SITE_PRACTICEASSISTANT_AZURE_="https://ppitoolkitdirectina.azurewebsites.net/INA",
    "http://localhost:8088/", // APP_SITE_ESTATEPROTECTION_LOCAL: 
    "https://test-tkdirectestateprotection.ppi.ca", // APP_SITE_ESTATEPROTECTION_TEST: 
    "https://toolkitdirectestateprotection.ppi.ca", // APP_SITE_ESTATEPROTECTION_PROD: 
]   

export const NAVBAR_SWITCH_WIDTH = 1024

export function getURL(appletPath)
{
    if (appletPath===PATHS.INA)
        return APP_SITE_INA[buildMode] 
    else  if (appletPath===PATHS.LIFO)
        return APP_SITE_LIFO[buildMode] 
    else  if (appletPath===PATHS.WL)
        return APP_SITE_WHOLELIFE[buildMode] 
    else  if (appletPath===PATHS.PA)
        return APP_SITE_PRACTICEASSISTANT[buildMode] 
    else if (appletPath===PATHS.EP)
        return APP_SITE_ESTATEPROTECTION[buildMode] 
    else
        return APP_SITE_INA[buildMode] 

}

export function  getAppletName(appletURL, lang){
  
    if (APP_SITE_INA.includes(appletURL))
        return TOOLKIT[lang].INA
    else if (APP_SITE_LIFO.includes(appletURL))
        return TOOLKIT[lang].LIFO
    else if (APP_SITE_WHOLELIFE.includes(appletURL))
        return TOOLKIT[lang].WL
    else if (APP_SITE_PRACTICEASSISTANT.includes(appletURL))
        return TOOLKIT[lang].PA
    else if (APP_SITE_ESTATEPROTECTION.includes(appletURL))
        return TOOLKIT[lang].EP
    else
        return TOOLKIT[lang].INA
}

