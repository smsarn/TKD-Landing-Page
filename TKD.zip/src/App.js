import React, { Component } from 'react';
import { Route, Redirect } from 'react-router';
import { withRouter } from 'react-router-dom';
import { Layout } from './components/Layout';
import { AppletHome } from './components/AppletHome';
import { AppletHomeNoPPI } from './components/AppletHomeNoPPI';

import { Applet } from './components/Applet';
//import { NA } from './components/OLD_NA';
//import { WL } from './components/old-WL';
//import { PracticeAssistant } from './components/OLD_PracticeAssistant';
//import { EstateProtection } from './components/OLD_EstateProtection';
import toolkitdirectlogoenglish from './Images/toolkit.direct.logo_english_rgb_reverse.png';
import toolkitdirectlogofrench from './Images/toolkit.direct.logo_french_rgb_reverse.png';
import toolkitdirectlogoenglishNoPPI from './Images/toolkit.direct.logo_english_rgb_reverse No PPI.png';
import toolkitdirectlogofrenchNoPPI from './Images/toolkit.direct.logo_french_rgb_reverse No PPI.png';

import './App.css';
import { CacheBuster } from "./CacheBuster";
import queryString from 'query-string';
import { version } from '../package.json';
import { APP_SITE_INA, APP_SITE_PRACTICEASSISTANT, APP_SITE_WHOLELIFE, APP_SITE_LIFO, APP_SITE_ESTATEPROTECTION,PATHS,TOOLKIT,getURL } from './Utils/util';


export default class App extends Component {
	displayName = "PPI Toolkit Direct";
	constructor(props) {
		super(props);
		var lang = window.navigator.userLanguage || window.navigator.language;
		lang = lang.toString().indexOf("en")>=0 ? "en" : "fr";
        this.state = {
            language: lang,
            loading: true,
            selectedApplet:"Home",
            logoSource: lang === "en" ? toolkitdirectlogoenglish : toolkitdirectlogofrench,
            
         //y   showSelectApplet: 0,
            redirectTo: "",
            QS: {
                PA: "",
                WL: "",
                INA: "",
                EP: "",
                LIFO: ""
            }
        };
		this.langText = "English";
        this.visible = true;
        this.visiblePPI = true;
        this.minimizedClicked = false;
        this.redirectTo2 = ""
        this.QS2 = "";
        this.sideBarMinimized= false;
        
	}

    componentDidMount = () => {
        this.minimizedClicked = false;
        this.sideBarMinimized= false;
        const query = queryString.parse(window.location.search);
        if (query.lang !== undefined) 
        this.setLanguage(query.lang);
        
        if (!(query.QS === undefined && query.applet === undefined)) {
           this.updateRedirectAndQS(query.applet, query.QS);
        }

        window.addEventListener('message', this.handleIframeTask);
    }

    redirectClear = () => {
        //setTimeout(() => {
        //this.setState({
        //    redirectTo: ""
        //    });
        ////    }, 2000);
        ////},

        const qs = {
            PA: "",
            WL: "",
            INA: "",
            EP: "",
            LIFO: ""
        }
        if (this.state.QS.EP !== qs.EP || this.state.QS.WL !== qs.WL || this.state.QS.INA !== qs.INA || this.state.QS.LIFO !== qs.LIFO||this.state.QS.PA !== qs.PA )

        setTimeout(() => {
          
            
                this.setState({
                    QS: qs, redirectTo:""
                })
            }, 2000);
        
    }



    redirectClear2 = () => {
        setTimeout(() => {
            this.QS2 = "";
        }, 500);
    }


    handleIframeTask = (e) => {
        if (e.data !== "") {
            //this.setState({
            //    redirectTo: ""
            //});
            //const divider = e.data.indexOf("_");
            //let redirect = e.data.substring(0, divider);
            //if (redirect === "EP")
            //    redirect = "/EstateProtection"
            //else if (redirect === "LIFO")
            //   redirect = "/LIFO";
            //else if (redirect === "INA") 
            //    redirect = "/INA";
            //this.QS2 = e.data.substring(divider + 1, e.data.length);
           
            //this.setState({
            //    redirectTo: redirect
            //});
            const str=e.data
            const divider1 = str.indexOf("_");
            const divider2 = str.lastIndexOf("_");
            if(divider2>divider1) // has language flag
            {
                const lang = str.substring(
                    divider1 + 1, 
                    divider2
                );
                this.setLanguage(lang)
            }
            let redirectToApplet = str.substring(0, divider1);
            const QS = str.substring(divider2 + 1, str.length)
            this.updateRedirectAndQS(redirectToApplet, QS)
        }
    };

    setLanguage=(lang)=>{
            //    console.log(lang)
                const logoSource= lang === "en" ? toolkitdirectlogoenglish : toolkitdirectlogofrench
                this.setState({language: lang, logoSource:logoSource});}


    updateRedirectAndQS = (redirectToApplet, QS) => {
        this.setState({
            redirectTo: ""
        });
        const applet=redirectToApplet.toLowerCase();
/*         let redirect = "/INA";
        if (applet === "ep"||applet === "pye")
            redirect = "/EstateProtection"
        else if (applet === "lifo")
            redirect = "/LIFO";
        else if (applet === "ina")
            redirect = "/INA";
        else if (applet === "pa" || applet === "practiceassistant")
            redirect = "/PracticeAssistant";
        else if (applet === "ifywl" || applet === "wl")
            redirect = "/WHOLELIFE";
        else if (applet !== "")
            redirect = "/INA";
 */
            let redirect =PATHS.INA;// "/INA";
            if (applet === "ep"||applet === "pye")
                redirect = PATHS.EP;// "/EstateProtection"
            else if (applet === "lifo")
                redirect = PATHS.LIFO;// "/LIFO";
            else if (applet === "ina")
                redirect = PATHS.INA; // "/INA";
            else if (applet === "pa" || applet === "practiceassistant")
                redirect = PATHS.PA;// "/PracticeAssistant";
            else if (applet === "ifywl" || applet === "wl")
                redirect = PATHS.WL; // "/WHOLELIFE";
            else if (applet !== "")
                redirect = PATHS.INA;// "/INA";
    


        this.QS2 = QS!==undefined?QS:"";

        this.setState({
            redirectTo: redirect
        });




    }


   /*  setQS = (QS, redirect) => {

        const qs= {
            PA: "",
                WL: "",
                    INA: "",
                        EP: "",
                            LIFO: ""
        }
        // ...
        if (redirect === "EstateProtection") 
            qs.EP=QS
        else if (redirect === "LIFO")
            qs.LIFO = QS
        else if (redirect === "INA")
            qs.INA = QS
        else if (redirect === "PA")
            qs.PA = QS
        else if (redirect === "WHOLELIFE")
            qs.WL = QS

        this.setState({ QS: qs})


    }
 */
	clearListCookies = () => {
	//console.log(document.cookie);
	var cookies = document.cookie.split(";");
	for (var i = 0; i < cookies.length; i++) {
		var spcook = cookies[i].split("=");
		deleteCookie(spcook[0]);
	}

	function deleteCookie(cookiename) {
		var d = new Date();
		d.setDate(d.getDate() - 1);
		var expires = ";expires=" + d;
		var name = cookiename;
		//alert(name);
		var value = "";
		document.cookie = name + "=" + value + expires + "; path=/acc/html";
	}
	localStorage.clear();
	//window .location = ""; // TO REFRESH THE PAGE
}

  convertVersion=(ver)=> {
	let verNo = 0;
	let inS = ver.indexOf(".");
	verNo = ver.substring(0, inS);
	let verS = this.num(Number(verNo));
	let inS2 = ver.indexOf(".", inS + 1);
	verNo = ver.substring(inS + 1, inS2);
	verS += this.num(Number(verNo));
	verNo = ver.substring(inS2 + 1, ver.length);
	verS += this.num(Number(verNo));
	//console.log(Number(verS));
	return Number(verS);

}
num=(n)=> {
	return n > 9 ? "" + n : "0" + n;
}

    selectApplet = (applet) => {
        if(this.state.selectedApplet!==applet)
            this.setState({selectedApplet:applet})

    }

	changeLang = () => {
		
		var data2 = this.state;
		var oldLang = this.state.language;
        data2.language = this.state.language === "en" ? "fr" : "en";
        data2.logoSource = this.state.language === "en" ? toolkitdirectlogoenglish : toolkitdirectlogofrench 
		this.langText = this.state.language === "en" ? "Fran�ais" : "English";
		this.setState({ data2, loading: false });
    }
    changeLogo = (mode) => {
        
        var data2 = this.state;
        if (mode === true) {
            var logoSource1 = this.state.language === "en" ? toolkitdirectlogoenglish : toolkitdirectlogofrench;
            var logoSource2 = this.state.language === "en" ? toolkitdirectlogoenglishNoPPI : toolkitdirectlogofrenchNoPPI;
            this.visiblePPI = data2.logoSource === logoSource2
            data2.loading=true
            data2.logoSource = this.state.logoSource === logoSource1 ? logoSource2 : logoSource1;
           
        }
        this.visible = false;
        this.setState({ data2, loading: false });

    }

    minimizeSideBar = () => {
        this.minimizedClicked = true;
        this.sideBarMinimized= !this.sideBarMinimized;
        
        if (document.getElementById("goh")!== null && document.getElementById("goh")!== undefined)
            document.getElementById("goh").className=this.sideBarMinimized=== true ? "appletiFrameExp" : "appletiFrame"
         /* 
        this.setState(prevState => {
            const newState = { ...prevState };
            newState.loading = false;
            newState.sideBarMinimized = !newState.sideBarMinimized;//== "240px" ? "20px" : "240px";
            return newState;
        }) */
    }

    simulateClickPA(e) {
        e.click()
    }

   
	//updateDataLang = (oldLang) => {
	//	let data2 = this.state;
	//	var o = NEEDSATDEATH[oldLang].cashNeeds.Values;
	//	var newLang = this.state.lang;
	//	data2.dataLiabilitys.Liabilitys.forEach(function (element) {
	//		//alert(o.indexOf(element.Type));
	//		element.Type = NEEDSATDEATH[newLang].cashNeeds.Values[o.indexOf(element.Type)];
	//		//alert(element.Type);
	//	});
	//	this.setState({ data2 }, () => this.wait());
	//	//	this.openParent = true;
	//}

	render() {
        const INA_URL = getURL(PATHS.INA);//  buildMode === 0 ? APP_SITE_INA.APP_SITE_INA_LOCAL : (buildMode === 1 ? APP_SITE_INA.APP_SITE_INA_TEST : APP_SITE_INA.APP_SITE_INA_PROD);
        const PA_URL = getURL(PATHS.PA);//buildMode === 0 ? APP_SITE_PRACTICEASSISTANT.APP_SITE_PRACTICEASSISTANT_LOCAL : (buildMode === 1 ? APP_SITE_PRACTICEASSISTANT.APP_SITE_PRACTICEASSISTANT_TEST : APP_SITE_PRACTICEASSISTANT.APP_SITE_PRACTICEASSISTANT_PROD);
        const WL_URL = getURL(PATHS.WL);//buildMode === 0 ? APP_SITE_WHOLELIFE.APP_SITE_WHOLELIFE_LOCAL : (buildMode === 1 ? APP_SITE_WHOLELIFE.APP_SITE_WHOLELIFE_TEST : APP_SITE_WHOLELIFE.APP_SITE_WHOLELIFE_PROD);
        const EP_URL = getURL(PATHS.EP);//buildMode === 0 ? APP_SITE_ESTATEPROTECTION.APP_SITE_ESTATEPROTECTION_LOCAL : (buildMode === 1 ? APP_SITE_ESTATEPROTECTION.APP_SITE_ESTATEPROTECTION_TEST : APP_SITE_ESTATEPROTECTION.APP_SITE_ESTATEPROTECTION_PROD);
        const LIFO_URL = getURL(PATHS.LIFO);//buildMode === 0 ? APP_SITE_LIFO.APP_SITE_LIFO_LOCAL : (buildMode === 1 ? APP_SITE_LIFO.APP_SITE_LIFO_TEST : APP_SITE_LIFO.APP_SITE_LIFO_PROD);
      //  const showPA = this.state.showSelectApplet === 1
        const noQS = this.state.QS.INA !== "" && this.convertVersion(version) > 10003;
        this.redirectClear2()    
     

		return (
			<CacheBuster>
				{({ loading, isLatestVersion, refreshCacheAndReload }) => {
					if (loading) return null;
					if (!loading && !isLatestVersion) {
						// You can decide how and when you want to force reload
						refreshCacheAndReload();
					}

		//localStorage.clear();

                   /*  if (showPA === true)

                       return (
                          ""
                        );



                    else */
                    return (
                        <Layout language={this.state.language} selectedApplet={this.state.selectedApplet} changeLang={this.changeLang} logoSource={this.state.logoSource} changeLogo={this.changeLogo} visible={this.visible} minimizeSideBar={this.minimizeSideBar} sideBarMinimized={this.sideBarMinimized} redirectTo={this.state.redirectTo} redirectClear={this.redirectClear}>
                                {noQS === true ?
                                    <Route exact path='/' render={(props) => <Applet {...props} QS={this.QS2} recover={this.minimizedClicked} language={this.state.language} appletiFrameExp={this.sideBarMinimized} appletURL={INA_URL} changeLang={this.changeLang} />} />
                                    : (this.visiblePPI === true ? <Route exact path='/' render={(props) => <AppletHome {...props} language={this.state.language} changeLang={this.changeLang} />} />
                                        : <Route exact path='/' render={(props) => <AppletHomeNoPPI {...props} language={this.state.language} changeLang={this.changeLang} />} />
                                    )}
                            {/* <Route path='/PracticeAssistant'  render={(props) => <Applet {...props} QS={this.QS2} language={this.state.language} appletiFrameExp={this.sideBarMinimized} appletURL={PA_URL} changeLang={this.changeLang} selectApplet={this.selectApplet}/>} simulateClickPA={this.simulateClickPA}  />
                            <Route path='/INA' render={(props) => <Applet {...props} QS={this.QS2} recover={this.minimizedClicked} language={this.state.language} appletiFrameExp={this.sideBarMinimized} appletURL={INA_URL} changeLang={this.changeLang} />} />
                            <Route path='/WHOLELIFE' render={(props) => <Applet {...props} QS={this.QS2} language={this.state.language} appletiFrameExp={this.sideBarMinimized} appletURL={WL_URL} changeLang={this.changeLang} />} />
                            <Route path='/LIFO' render={(props) => <Applet {...props} QS={this.QS2} language={this.state.language} appletiFrameExp={this.sideBarMinimized} appletURL={LIFO_URL} changeLang={this.changeLang} />} />
                            <Route path='/EstateProtection' render={(props) => <Applet {...props} QS={this.QS2} language={this.state.language} appletiFrameExp={this.sideBarMinimized} appletURL={EP_URL} changeLang={this.changeLang}/>} />
                             */}
                            <Route path= {PATHS.PA}  render={(props) => <Applet {...props} QS={this.QS2} language={this.state.language} appletiFrameExp={this.sideBarMinimized} appletURL={PA_URL} changeLang={this.changeLang} selectApplet={this.selectApplet}/>} simulateClickPA={this.simulateClickPA}  />
                            <Route path= {PATHS.INA} render={(props) => <Applet {...props} QS={this.QS2} recover={this.minimizedClicked} language={this.state.language} appletiFrameExp={this.sideBarMinimized} appletURL={INA_URL} changeLang={this.changeLang}  selectApplet={this.selectApplet} />} />
                            <Route path= {PATHS.WL} render={(props) => <Applet {...props} QS={this.QS2} language={this.state.language} appletiFrameExp={this.sideBarMinimized} appletURL={WL_URL} changeLang={this.changeLang}  selectApplet={this.selectApplet}/>} />
                            <Route path= {PATHS.LIFO} render={(props) => <Applet {...props} QS={this.QS2} language={this.state.language} appletiFrameExp={this.sideBarMinimized} appletURL={LIFO_URL} changeLang={this.changeLang}  selectApplet={this.selectApplet}/>} />
                            <Route path= {PATHS.EP} render={(props) => <Applet {...props} QS={this.QS2} language={this.state.language} appletiFrameExp={this.sideBarMinimized} appletURL={EP_URL} changeLang={this.changeLang }  selectApplet={this.selectApplet}/>} />
                            

                            </Layout>
                        );

                    
				}}
			</CacheBuster>
		);
  }
}
