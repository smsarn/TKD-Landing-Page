﻿import React from 'react';
import './NA.css';
import {getAppletName, APP_SITE_INA, APP_SITE_PRACTICEASSISTANT, APP_SITE_WHOLELIFE, APP_SITE_LIFO, APP_SITE_ESTATEPROTECTION } from '../Utils/util';

export class Applet extends React.Component {

    constructor(props) {
        super(props);
     }
    componentDidMount(){
        this.reload();
    }
    componentWillReceiveProps(nextProps) {
        this.reload();
    }
    
    reload=()=>{
        document.getElementById("goh").onload=()=>{document.getElementById('goh').style.display="block"}
    }

   

    render() {
        const lang = this.props.language === "en" ? "Français" : "English";
        let dataToPass = (this.props.QS !== "" ? "&QS=" + this.props.QS : "") + (this.props.recover !== "" ? "&recover=" + this.props.recover : "") + "&a=" + Math.random();
        
        let url = this.props.appletURL;

        let isIE = /*@cc_on!@*/false || !!document.documentMode;
        let appletiFrameClass = this.props.appletiFrameExp === true ? "appletiFrameExp" : "appletiFrame"
        let msg = this.props.language === "en" ? "Please use Google Chrome or Microsoft Edge (version 18 or higher) browsers" : "s'il vous plaît utiliser les navigateurs Google Chrome ou Microsoft Edge (version 18 +)";
        
        this.props.selectApplet(getAppletName(this.props.appletURL, this.props.language ))

        const src=url + "?lang=" + this.props.language + dataToPass;
        return (
            <div className="appletDiv">
                {isIE ? <div className="ie"> {msg}
                </div> :
                    <iframe id="goh" className={appletiFrameClass} src={src} style={{display:"none"}}/>

                }
                {/*<div><input className="language" onClick={this.props.changeLang} type="button" value={lang} />
				</div>*/}
            </div>
        );
    }
}


