﻿import React, { Component } from 'react';
import { useLocation, Link } from 'react-router-dom'

import { Redirect } from 'react-router';
import { Glyphicon, Nav, Navbar, NavItem } from 'react-bootstrap';
import { LinkContainer } from 'react-router-bootstrap';

import './NavMenu.css';
//import screenShareMsgEn from './toolkit.direct_screen.sharing.banner_208x391px2.jpg';
//import screenShareMsgFr from './toolkit.direct_screen.sharing.banner_208x391px_fr2.jpg';
//import screenShareMsgEn from './toolkit.direct_screen.sharing_quick.tip.jpg';
//import screenShareMsgFr from './toolkit.direct_screen.sharing_quick.tip_fr.jpg';
//import screenShareMsgEn from './toolkit.direct_screen.sharing_quick.tip.gif';
//import screenShareMsgFr from './toolkit.direct_screen.sharing_quick.tip_FR.gif';
//import newInToolkitMsgEn from './toolkit.direct_new.features_ina.gif';
//import newInToolkitMsgFr from './toolkit.direct_new.features_ina_FR.gif';
import screenShareMsgEn from '../Images/toolkit.direct_quick.tip_20.8.14.gif';
import screenShareMsgFr from '../Images/toolkit.direct_quick.tip_20.8.14_Fr.gif';
//import newInToolkitMsgEn from '../Images/toolkit.direct_new.features_20.8.14.gif';
//import newInToolkitMsgFr from '../Images/toolkit.direct_new.features_20.8.14_FR.gif';
// added PYE
//import newInToolkitMsgEn from '../Images/toolkit.direct_Insurance.Needs.Analysis_new.features_20.12.gif';
//import newInToolkitMsgFr from '../Images/toolkit.direct_Insurance.Needs.Analysis_new.features_20.12.8_FR.gif';
// added LIFO
import newInToolkitMsgEn from '../Images/tkd_new.applets_21.01.gif';
import newInToolkitMsgFr from '../Images/tkd_new.applets_21.01_FR.gif';
import { NAVBAR_SWITCH_WIDTH, PATHS, TOOLKIT } from  '../Utils/util';

const NO_APPLETS = 5

/* const TOOLKIT = {
	en: {
		Title: 'PPI Toolkit Direct',
		Home: 'Home',
		Applets:'Applets',
		NA: 'Insurance Needs Analysis',
		WL: 'Insurance for Your Whole Life',
		EstateProtection: 'Protecting Your Estate',
        PracticeAssistant: 'Practice Assistant',
        LIFO: 'Life Insurance Funding Options'
	},
	fr: {
		Title: 'Boîte à outils directe- PPI',
		Home: 'Principal',
		Applets: 'Applets',
		NA: "Analyse des besoins en matière d'assurance",
		WL: 'L\'assurance pour votre vie entière',
        EstateProtection: 'Protection de votre patrimoine',
        PracticeAssistant: 'Assistant à la conformité',
        LIFO: "Modes de financement de l'assurance vie"
	}
} */

export class NavMenu extends Component {
    displayName = "PPI APIs"
    reload = () => {

        window.location.reload();
    }
    constructor(props) {
        super(props);
        this.el1 = React.createRef();
        this.el2 = React.createRef();
        this.state = {
            //showMinimizeArrow: false,
            width: 0, 
            height: 0,
            showBanner:true,
            sideBarMinimized:false ,
            showSaveMsg: false,
        };
        this.msgVisible = false;
        this.showBanner=true;
        this.checkedRemoveLogo = false;
        //this.minimizeSideBar=false
    }
    updateDimensions = () => {
        this.setState({ width: window.innerWidth, height: window.innerHeight });
      };
    componentDidMount() {
        window.addEventListener('resize', this.updateDimensions);
      }
      componentWillUnmount() {
        window.removeEventListener('resize', this.updateDimensions);
      }

    componentWillReceiveProps(nextProps) {
    //    if (this.props.redirectTo !== "")
    //        this.props.redirectClear(this.props.redirectTo);
    }


    changeLogo = () => {
        this.msgVisible === false;
        this.props.changeLogo(true);
    }
     
    removeBanner = () => {
        this.setState({showBanner: false})
        
    }

    sideBarHideShow  = () => {
        
        const sb=!this.state.sideBarMinimized 
        this.props.minimizeSideBar();
        this.setState({sideBarMinimized : sb})
        
    }

    

    fetchTest = () => {

		//fetch("https://test-tkdirectapi.ppi.ca/api/MCC_Carriers", {
		//	method: 'GET',
		//	redirect: 'follow',
		//	credentials: 'same-origin',
		//	withCredentials: 'true'
		//	})
		//	.then(response => {
		//		return response.json();
		//	})
		//	.then(data => {
		//		console.log(data);
		//	}
		//	)
		//	.catch(error => {
		//		console.log('error, test failed', error);
		//	});
        
	}

    /* handleClick = (show) => {
        this.setState({showMinimizeArrow: show})
    }
 */
    handleMouseIn(e) {
        const showMsg= !(e.target.innerHTML.includes(this.props.selectedApplet) || this.props.selectedApplet.includes("Home"))
        this.setState({showSaveMsg:showMsg})
      }
      
      handleMouseOut() {
        this.setState({showSaveMsg:false})
      }
      

    render() {

       
        const lang = this.props.language;
        const style = { width: '100%',marginTop:'6px'};
        const lang2 = this.props.language === "en" ? "Français" : "English";
        //const style4 = { width: this.props.sideBarWidth };
        //console.log(this.props);
        const screenShareMsg = lang === "en" ? screenShareMsgEn : screenShareMsgFr;
        const newINAMsg = lang === "en" ? newInToolkitMsgEn : newInToolkitMsgFr;
        

         const styleButt = this.props.visible ? "buttonClose hide" : "buttonClose hide" // dont show
        const arrowLeft = <span style={{ color: "#f5f6f6" }}>&#9668;</span>
        const arrowRight = <span style={{ color: "#f5f6f6" }}>&#9658;</span>
        const styleMsg1 = { bottom: this.props.language === "en" ? '32%' : '30%' }
        const styleMsg2 = { bottom: this.props.language === "en" ? '20%' : '18%' }
        //const styleButt1Hidden = { bottom: this.props.language === "en" ? '32%' : '30%', width: '8%', height: '5%', visibility: this.props.visible === true ? "visible" : "hidden" }
        //const styleButt2Hidden = { bottom: this.props.language === "en" ? '20%' : '18%', width: '8%', height: '5%', visibility: this.props.visible === true ? "visible" : "hidden" }
const availH=window.screen.availHeight
        const sideBarContent = { visibility: this.state.sideBarMinimized === true ? "hidden" : "visible"} 
        
        const saveMessage = {visibility: this.state.showSaveMsg === false ? "hidden" : "visible"} 

        const bannersStyle = { position: 'relative', float: 'left', marginLeft: '10px', marginTop: '-10px', visibility: this.state.sideBarMinimized === true ? "hidden" : "visible" }
        const noApplets=NO_APPLETS;
        const minHeight=noApplets*(lang === "en" ? 70:availH>1080?65:80);
        // console.log(window.innerHeight,window.screen.availHeight,window.innerWidth)
        let appletNavHeight=  Math.max(minHeight,(lang === "en" ?350:250)*window.innerHeight/availH);
        let banner1Hide=lang === "en" ?11.2*availH/20:13*availH/20;
        let banner2Hide=lang === "en" ?14.2*availH/20:16.7*availH/20;
        const styleBanner = this.props.visible ? "msgBanner" : "msgBanner hide";
       
        const userAgent = navigator.userAgent.toLowerCase();
        const isTablet = /(ipad|tablet|(android(?!.*mobile))|(windows(?!.*phone)(.*touch))|kindle|playbook|silk|(puffin(?!.*(IP|AP|WP))))/.test(userAgent);
        if(isTablet){
            banner1Hide=0;
            banner2Hide=0;
            if(window.innerHeight > window.innerWidth)
                appletNavHeight=420;
            else{
                appletNavHeight=lang === "en" ?300:370;
                banner2Hide=lang === "en" ?0:availH;
            }
            
        }

        return (
            <Navbar inverse fixedTop fluid collapseOnSelect className={this.state.sideBarMinimized === false ? "navbar" : "navbarMinimized"}>
                {/* {this.state.showMinimizeArrow == true && window.innerWidth > NAVBAR_SWITCH_WIDTH && <button className="arrow" onClick={this.sideBarHideShow} >{this.state.sideBarMinimized === false ? arrowLeft : arrowRight}</button>} */}
                {window.innerWidth > NAVBAR_SWITCH_WIDTH && <button className="arrow" onClick={this.sideBarHideShow} >{this.state.sideBarMinimized === false ? arrowLeft : arrowRight}</button>}
               <Navbar.Header>
					<Navbar.Brand>
                        <div  > <img onClick={this.changeLogo} src={this.props.logoSource} style={style}/>
							</div>
							
                    </Navbar.Brand>
                    

					<Navbar.Toggle />
				</Navbar.Header>
                <div style={sideBarContent}>
				<Navbar.Collapse>
                        <Nav style={{ height: appletNavHeight+"px" }}>
                            <LinkContainer to={'/'} style={{ marginLeft: '2px' }}  exact>
							<NavItem>
									<Glyphicon glyph='home' /> {TOOLKIT[lang].Home}
									<span style={{
										fontWeight: 'normal', float: 'right', fontSize: '8px', marginTop: '2px', marginRight: '-8px' }}> {global.appVersion} </span>

							</NavItem>
						</LinkContainer>

						{/*<Navbar.Header>
							<Navbar.Brand>
								<span style={{ color: '#E4E5E6', marginLeft: '9px', fontSise: '14px' }}><Glyphicon glyph='th-list' /><span style={{ marginLeft: '10px' }}>Applets</span></span>
							</Navbar.Brand>
							<Navbar.Toggle />
						</Navbar.Header>

						
							<NavItem style={{ marginLeft: '30px' }}>
							<span>Applet 1</span>
									</NavItem>

						<NavItem style={{ marginLeft: '30px' }}>
							<span>Applet 2</span>
									</NavItem>	   */}

								
                            <LinkContainer to={PATHS.PA} style={{ marginLeft: '30px' }}  >
                                <NavItem  /* onClick={() => this.handleClick(false)} */>
                                    <span onMouseOver={e => this.handleMouseIn(e)} onMouseOut={this.handleMouseOut.bind(this)} >{TOOLKIT[lang].PA}</span>
                                </NavItem>

                        </LinkContainer>
                            <LinkContainer to={PATHS.INA} style={{ marginLeft: '30px' }}  >
                                <NavItem   /* onClick={() => this.handleClick(true)} */>
                                   <span  onMouseOver={e => this.handleMouseIn(e)} onMouseOut={this.handleMouseOut.bind(this)} >{TOOLKIT[lang].INA}</span>
                                </NavItem>

                            </LinkContainer>
                            <LinkContainer to={ PATHS.EP} style={{ marginLeft: '30px' }}  >
                                    <NavItem /* onClick={() => this.handleClick(false)} */>
									   <span  onMouseOver={e => this.handleMouseIn(e)} onMouseOut={this.handleMouseOut.bind(this)} >{TOOLKIT[lang].EP}</span>
									</NavItem>

								</LinkContainer>
						<LinkContainer to={ PATHS.WL} style={{ marginLeft: '30px' }}>
                                <NavItem /* onClick={() => this.handleClick(false)} */>
								<span   onMouseOver={e => this.handleMouseIn(e)} onMouseOut={this.handleMouseOut.bind(this)}>{TOOLKIT[lang].WL}</span>
									</NavItem>

							</LinkContainer>
                            <LinkContainer to= {PATHS.LIFO} style={{ marginLeft: '30px' }}  >
                            <NavItem/* onClick={() => this.handleClick(true)} */>
                               <span  onMouseOver={e => this.handleMouseIn(e)} onMouseOut={this.handleMouseOut.bind(this)} >{TOOLKIT[lang].LIFO}</span>
                            </NavItem>

                        </LinkContainer>
                        <span><input className="saveMsg" style={saveMessage} type="button" value={"Save any unsaved data ^F..."} /> </span>
                   
                        </Nav>
                        {this.state.showBanner===true && window.innerWidth > NAVBAR_SWITCH_WIDTH && window.window.innerHeight>banner1Hide && <div style={sideBarContent} ref={this.el1} > <img style={sideBarContent} src={newINAMsg} className={styleBanner} onClick={this.removeBanner} /></div>}
                        {this.state.showBanner===true && window.innerWidth > NAVBAR_SWITCH_WIDTH   && window.window.innerHeight>banner2Hide && <div style={sideBarContent} ref={this.el2} > <img style={sideBarContent} src={screenShareMsg} className={styleBanner} onClick={this.removeBanner} /></div>}
                        <div style={sideBarContent}>{/*<span className="browser"> {"Google Chrome Microsoft Edge (18+) iPad/iPhone: Safari Firefox"} </span>*/}
                            <span><input className="language" onClick={this.props.changeLang} type="button" value={lang2} /> </span>
                         </div>
                    </Navbar.Collapse>
                </div>
                {this.props.redirectTo !== "" &&
                    <Redirect to={this.props.redirectTo} />}
            </Navbar>
            
		);
	}
}
